package utils.validation;

public interface ValidationUtil {
    /** Validates that a sheet name is unique in the system.*/
    boolean isSheetNameUnique(String sheetName);

    /** Validates the structure and content of the XML file uploaded as a sheet.*/
    boolean validateXMLFile(String xmlContent);
}
