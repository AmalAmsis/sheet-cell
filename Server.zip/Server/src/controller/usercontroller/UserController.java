package controller.usercontroller;

import model.user.User;

public interface UserController {

    /** Authenticates a user based on username.*/
    User authenticateUser(String username) throws Exception;

    /** Logs out the user from the system.*/
    void logoutUser(User user) throws Exception;

    /** Registers a new user (if applicable).*/
    void registerUser(String username) throws Exception;
}
