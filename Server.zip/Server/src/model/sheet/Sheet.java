package model.sheet;

import java.util.List;

public interface Sheet {

    /**
     * Get the unique ID of the sheet.
     * @return The sheet ID as a String.
     */
    String getSheetId();

    /**
     * Set the unique ID of the sheet.
     * @param sheetId The sheet ID as a String.
     */
    void setSheetId(String sheetId);

    /**
     * Get the name of the sheet.
     * @return The sheet name as a String.
     */
    String getSheetName();

    /**
     * Set the name of the sheet.
     * @param sheetName The sheet name as a String.
     */
    void setSheetName(String sheetName);

    /**
     * Get the number of rows in the sheet.
     * @return The number of rows.
     */
    int getRows();

    /**
     * Set the number of rows in the sheet.
     * @param rows The number of rows.
     */
    void setRows(int rows);

    /**
     * Get the number of columns in the sheet.
     * @return The number of columns.
     */
    int getColumns();

    /**
     * Set the number of columns in the sheet.
     * @param columns The number of columns.
     */
    void setColumns(int columns);

    /**
     * Get the owner ID of the sheet.
     * @return The owner ID as a String.
     */
    String getOwnerId();

    /**
     * Set the owner ID of the sheet.
     * @param ownerId The owner ID as a String.
     */
    void setOwnerId(String ownerId);

    /**
     * Get the list of editors who have access to the sheet.
     * @return A list of editor usernames as Strings.
     */
    List<String> getEditors();

    /**
     * Set the list of editors who have access to the sheet.
     * @param editors A list of editor usernames as Strings.
     */
    void setEditors(List<String> editors);
}
