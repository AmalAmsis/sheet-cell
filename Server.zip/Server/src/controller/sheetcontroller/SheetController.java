package controller.sheetcontroller;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

public interface SheetController {

    /** Handles requests to upload a sheet (e.g., via a POST request).*/
    void uploadSheet(HttpServletRequest request, HttpServletResponse response) throws IOException;

    /**Handles requests to list all sheets for the logged-in user.*/
    void listSheets(HttpServletRequest request, HttpServletResponse response) throws IOException;

    /**Handles requests to view a specific sheet based on its ID.*/
    void viewSheet(HttpServletRequest request, HttpServletResponse response) throws IOException;

    /**Handles requests to manage sheet permissions (e.g., grant or revoke access).*/
    void managePermissions(HttpServletRequest request, HttpServletResponse response) throws IOException;
}

