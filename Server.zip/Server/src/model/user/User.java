package model.user;

public interface User {


    /**
     * Get the unique user ID.
     * @return The user's ID as a String.
     */
    String getUserId();

    /**
     * Set the unique user ID.
     * @param userId The user ID as a String.
     */
    void setUserId(String userId);

    /**
     * Get the username of the user.
     * @return The username as a String.
     */
    String getUsername();

    /**
     * Set the username of the user.
     * @param username The username as a String.
     */
    void setUsername(String username);
}
