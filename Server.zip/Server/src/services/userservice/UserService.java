package services.userservice;

import model.user.User;

public interface UserService {
    /** Authenticates a user based on username.*/

    User loginUser(String username) throws Exception;

    /**Logs out the user from the system.*/
    void logoutUser(User user) throws Exception;

    /** Registers a new user (if applicable).*/
    void registerUser(String username) throws Exception;
}
